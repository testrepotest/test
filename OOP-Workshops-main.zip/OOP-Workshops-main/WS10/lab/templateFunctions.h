//Name:
//ID:
//Email:
// Date:
//Section:

#ifndef SDDS_TEMPLATEFUNCTIONS_H_
#define SDDS_TEMPLATEFUNCTIONS_H_
#include <iostream>
#include "Collection.h"
namespace sdds {
	//Find with 3 parameters
	

	//Find with 4 parameters
	

	//Insertion operator
	

	//Load Collection
		

}
#endif // !SDDS_SEARCH_H_

